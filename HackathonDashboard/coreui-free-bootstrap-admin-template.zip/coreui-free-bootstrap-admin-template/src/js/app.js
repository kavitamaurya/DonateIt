var message = "";
console.log(global.message)